package com.skillovilla.java_advanced.lab5.level3;

@FunctionalInterface
public interface MathOperation {
    int operate(int a, int b);
}

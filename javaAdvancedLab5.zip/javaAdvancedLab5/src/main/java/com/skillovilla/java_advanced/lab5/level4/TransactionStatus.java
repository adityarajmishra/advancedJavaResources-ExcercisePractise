package com.skillovilla.java_advanced.lab5.level4;

public enum TransactionStatus {
    PENDING,
    COMPLETED,
    CANCELLED
}

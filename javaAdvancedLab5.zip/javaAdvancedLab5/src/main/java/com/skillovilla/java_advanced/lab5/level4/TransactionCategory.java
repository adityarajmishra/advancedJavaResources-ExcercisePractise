package com.skillovilla.java_advanced.lab5.level4;

public enum TransactionCategory {
    FOOD,
    ELECTRONICS,
    CLOTHING
}

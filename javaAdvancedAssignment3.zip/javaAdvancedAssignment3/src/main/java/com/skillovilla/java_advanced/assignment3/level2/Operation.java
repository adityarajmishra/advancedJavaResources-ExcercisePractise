package com.skillovilla.java_advanced.assignment3.level2;

@FunctionalInterface
public interface Operation {
    int operate(int a, int b);
}

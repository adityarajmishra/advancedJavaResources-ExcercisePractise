package com.skillovilla.java_advanced.lab3.level1;

public interface Formatter <T>{
    String format(T t);
}
